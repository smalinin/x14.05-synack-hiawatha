$(document).ready(function() {
	labels = $("table.label").detach();
	$("table.tablemanager").before(labels);
});
