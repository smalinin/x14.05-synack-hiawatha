<?php
	class admin_webserver_controller extends tablemanager_controller {
		protected $name = "Webserver";
		protected $pathinfo_offset = 2;
		protected $back = "admin";
		protected $icon = "webserver.png";
	}
?>
