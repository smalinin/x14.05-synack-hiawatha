<?php
	class security_statistics_controller extends graph_controller {
		protected $graphs = array(
			"bans"                  => "Clients banned",
			"exploit_attempts"      => "Exploit attempts");
	}
?>
