<?php
	class XXX_controller extends controller {
		public function execute() {
		}
	}
?>
