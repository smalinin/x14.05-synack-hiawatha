<?php
	class XXX_model extends model {
	}
?>
